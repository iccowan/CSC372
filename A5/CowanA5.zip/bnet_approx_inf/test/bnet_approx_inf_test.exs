defmodule BnetApproxInfTest do
  use ExUnit.Case
  doctest BnetApproxInf

end
