defmodule BnetExactInfTest do
  use ExUnit.Case
  doctest BnetExactInf

  test "greets the world" do
    assert BnetExactInf.hello() == :world
  end
end
