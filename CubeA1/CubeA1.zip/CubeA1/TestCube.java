public class TestCube {
    public static void main(String[] args) {
        Cube cube = new Cube();
        cube.front(1);
        cube.back(3);
        cube.print();
    }
}
